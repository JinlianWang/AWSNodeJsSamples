

Sunnys-iMac:KinesisDataStream jinlianwang$ aws kinesis create-stream --stream-name KinesisStreamPlayground --shard-count 1
Sunnys-iMac:KinesisDataStream jinlianwang$ aws lambda create-event-source-mapping --function-name KinesisConsumerPlayground --event-source-arn arn:aws:kinesis:us-east-1:804462227831:stream/KinesisStreamPlayground --starting-position LATEST
{
    "UUID": "32913be6-a2b0-47a0-b325-75b3e85fc5ea",
    "StartingPosition": "LATEST",
    "BatchSize": 100,
    "MaximumBatchingWindowInSeconds": 0,
    "ParallelizationFactor": 1,
    "EventSourceArn": "arn:aws:kinesis:us-east-1:804462227831:stream/KinesisStreamPlayground",
    "FunctionArn": "arn:aws:lambda:us-east-1:804462227831:function:KinesisConsumerPlayground",
    "LastModified": "2023-05-20T09:50:52.631000-04:00",
    "LastProcessingResult": "No records processed",
    "State": "Creating",
    "StateTransitionReason": "User action",
    "DestinationConfig": {
        "OnFailure": {}
    },
    "MaximumRecordAgeInSeconds": -1,
    "BisectBatchOnFunctionError": false,
    "MaximumRetryAttempts": -1,
    "TumblingWindowInSeconds": 0,
    "FunctionResponseTypes": []
}
Sunnys-iMac:KinesisDataStream jinlianwang$ ./putRecords.sh KinesisStreamPlayground
{
    "ShardId": "shardId-000000000000",
    "SequenceNumber": "49640939152828312488948265425371285803117693577348513794"
}
{
    "ShardId": "shardId-000000000000",
    "SequenceNumber": "49640939152828312488948265425372494728937308206523219970"
}
{
    "ShardId": "shardId-000000000000",
    "SequenceNumber": "49640939152828312488948265425373703654756922973136879618"
}
{
    "ShardId": "shardId-000000000000",
    "SequenceNumber": "49640939152828312488948265425374912580576537671031062530"
}
{
    "ShardId": "shardId-000000000000",
    "SequenceNumber": "49640939152828312488948265425376121506396152300205768706"
}
{
    "ShardId": "shardId-000000000000",
    "SequenceNumber": "49640939152828312488948265425377330432215766929380474882"
}
{
    "ShardId": "shardId-000000000000",
    "SequenceNumber": "49640939152828312488948265425378539358035381627274657794"
}
{
    "ShardId": "shardId-000000000000",
    "SequenceNumber": "49640939152828312488948265425379748283854996325168840706"
}
{
    "ShardId": "shardId-000000000000",
    "SequenceNumber": "49640939152828312488948265425380957209674610954343546882"
}
{
    "ShardId": "shardId-000000000000",
    "SequenceNumber": "49640939152828312488948265425382166135494225720957206530"
}
